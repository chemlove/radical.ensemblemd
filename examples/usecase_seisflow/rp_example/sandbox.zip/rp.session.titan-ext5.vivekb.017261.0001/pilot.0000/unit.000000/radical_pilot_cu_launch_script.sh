#!/bin/sh


# Change to working directory for unit
cd /lustre/atlas1/bip149/scratch/vivekb/radical.pilot.sandbox/rp.session.titan-ext5.vivekb.017261.0001/pilot.0000/unit.000000
# Environment variables
export RP_SESSION_ID=rp.session.titan-ext5.vivekb.017261.0001
export RP_PILOT_ID=pilot.0000
export RP_AGENT_ID=agent_1
export RP_SPAWNER_ID=agent.executing.0.child
export RP_UNIT_ID=unit.000000

# Pre-exec commands
module swap PrgEnv-pgi PrgEnv-gnu
module use --append /lustre/atlas/world-shared/bip103/modules
module load openmpi/DEVEL-STATIC
tar xf ipdata.tar
mkdir DATABASES_MPI
mkdir OUTPUT_FILES
cp -rf /lustre/atlas/scratch/vivekb/csc230/modules/specfem3d_globe/bin .
sed -i "s:^NUMBER_OF_SIMULTANEOUS_RUNS.*:NUMBER_OF_SIMULTANEOUS_RUNS = 1:g" DATA/Par_file
# The command to run
/lustre/atlas/world-shared/bip103/openmpi/static-nodebug/bin/orterun  --hnp "639107072.0;tcp://10.128.36.164,160.91.205.204:39872"  -np 4 -host 3791,3791,3791,3791 ./bin/xmeshfem3D
RETVAL=$?
# Post-exec commands
tar cf opdata.tar DATA/ DATABASES_MPI/ OUTPUT_FILES/ bin/

# Exit the script with the return code from the command
exit $RETVAL
