#!/bin/sh

exec /lustre/atlas/world-shared/bip103/openmpi/static-nodebug/bin/orterun  --hnp "639107072.0;tcp://10.128.36.164,160.91.205.204:39872"  -np 1 -host 2354 /bin/sh "/lustre/atlas1/bip149/scratch/vivekb/radical.pilot.sandbox/rp.session.titan-ext5.vivekb.017261.0001/pilot.0000/bootstrap_2.sh" "agent_1" 
