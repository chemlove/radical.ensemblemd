#!/bin/sh

# some inspection for logging
hostname

# make sure we use the correct sandbox
cd /lustre/atlas/scratch/vivekb/bip149/radical.pilot.sandbox/rp.session.titan-ext5.vivekb.017261.0001/pilot.0000

# apply some env settings as stored after running pre_bootstrap_1 commands
export PATH="/sw/xk6/python/2.7.9/sles11.3_gnu4.3.4/bin:/lustre/atlas/sw/xk7/python/2.7.9/sles11.3_gnu4.3.4/bin:/lustre/atlas/world-shared/bip103/openmpi/static-nodebug/bin:/opt/gcc/4.9.3/bin:/lustre/atlas/scratch/vivekb/csc230/miniconda2/bin:/lustre/atlas/scratch/vivekb/csc230/miniconda2/bin:/lustre/atlas/scratch/vivekb/csc230/miniconda2/bin:/lustre/atlas/scratch/vivekb/csc230/miniconda2/bin:/sw/xk6/bin:/sw/xk6/hsi/5.0.2.p1/sles11.5/bin:/sw/xk6/xalt/0.7.5/bin:/sw/xk6/lustredu/1.4/sles11.3_gnu4.8.2/bin:/opt/cray/craype/2.5.9/bin:/opt/cray/mpt/7.5.2/gni/bin:/opt/cray/llm/default/bin:/opt/cray/llm/default/etc:/opt/cray/xpmem/0.1-2.0502.64982.5.3.gem/bin:/opt/cray/ugni/6.0-1.0502.10863.8.28.gem/bin:/opt/cray/udreg/2.3.2-1.0502.10518.2.17.gem/bin:/opt/cray/lustre-cray_gem_s/2.8.0_3.0.101_0.46.1_1.0502.8871.21.1-1.0502.0.6.1/sbin:/opt/cray/lustre-cray_gem_s/2.8.0_3.0.101_0.46.1_1.0502.8871.21.1-1.0502.0.6.1/bin:/opt/cray/alps/5.2.4-2.0502.9950.37.1.gem/sbin:/opt/cray/alps/5.2.4-2.0502.9950.37.1.gem/bin:/opt/cray/sdb/1.1-1.0502.63652.4.27.gem/bin:/opt/cray/nodestat/2.2-1.0502.60539.1.31.gem/bin:/opt/modules/3.2.10.5/bin:/usr/bin:/usr/local/bin:/usr/bin:/bin:/usr/bin/X11:/usr/X11R6/bin:/usr/games:/opt/bin:/usr/lib/mit/bin:/usr/lib/mit/sbin:/usr/lib/qt3/bin:/opt/cray/bin:/opt/bin:/opt/public/bin:/opt/bin:/opt/public/bin:::/opt/bin:/opt/public/bin:/opt/bin:/opt/public/bin::"
export LD_LIBRARY_PATH="/sw/xk6/python/2.7.9/sles11.3_gnu4.3.4/lib:/lustre/atlas/sw/xk7/python/2.7.9/sles11.3_gnu4.3.4/lib:/lustre/atlas/world-shared/bip103/openmpi/static-nodebug/lib:/opt/gcc/4.9.3/snos/lib64"

# activate virtenv
if test "default" = "anaconda"
then
    source activate /lustre/atlas1/bip149/scratch/vivekb/radical.pilot.sandbox/ve_titan/
else
    . /lustre/atlas1/bip149/scratch/vivekb/radical.pilot.sandbox/ve_titan/bin/activate
fi

# make sure rp_install is used
export PYTHONPATH=/lustre/atlas/scratch/vivekb/bip149/radical.pilot.sandbox/rp.session.titan-ext5.vivekb.017261.0001/pilot.0000/rp_install/lib/python2.7/site-packages::/sw/xk6/python/2.7.9/sles11.3_gnu4.3.4/lib/python2.7/site-packages:/lustre/atlas/sw/xk7/python/2.7.9/sles11.3_gnu4.3.4/lib/python2.7/site-packages:/sw/xk6/xalt/0.7.5/site:/sw/xk6/xalt/0.7.5/libexec:/opt/cray/sdb/1.1-1.0502.63652.4.27.gem/lib64/py

# run agent in debug mode
# FIXME: make option again?
export SAGA_VERBOSE=DEBUG
export RADICAL_VERBOSE=DEBUG
export RADICAL_UTIL_VERBOSE=DEBUG
export RADICAL_PILOT_VERBOSE=DEBUG

# the agent will *always* use the dburl from the config file, not from the env
# FIXME: can we better define preference in the session ctor?
unset RADICAL_PILOT_DBURL

# avoid ntphost lookups on compute nodes
export RADICAL_PILOT_NTPHOST=46.101.140.169

# pass environment variables down so that module load becomes effective at
# the other side too (e.g. sub-agents).


# start agent, forward arguments
# NOTE: exec only makes sense in the last line of the script
exec /lustre/atlas1/bip149/scratch/vivekb/radical.pilot.sandbox/ve_titan/bin/python /lustre/atlas/scratch/vivekb/bip149/radical.pilot.sandbox/rp.session.titan-ext5.vivekb.017261.0001/pilot.0000/rp_install/bin/radical-pilot-agent "$1" 1>"$1.out" 2>"$1.err"

